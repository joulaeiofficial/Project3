<?php
require_once __DIR__ . '/includes/helpers.php';

$currentPath = isset($_GET['path']) ? trim($_GET['path'], '/') : '';
$listing = list_dir($currentPath);

$photoCount = count(array_filter($listing['files'], fn($f) => $f['type'] === 'image'));
$videoCount = count($listing['files']) - $photoCount;

// Breadcrumb segments: [label, path]
$crumbs = [];
if ($currentPath !== '') {
    $acc = '';
    foreach (explode('/', $currentPath) as $seg) {
        $acc = $acc === '' ? $seg : $acc . '/' . $seg;
        $crumbs[] = [$seg, $acc];
    }
}
$parentPath = '';
if (($pos = strrpos($currentPath, '/')) !== false) $parentPath = substr($currentPath, 0, $pos);

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $currentPath !== '' ? e(basename($currentPath)) . ' · ' : '' ?>My Gallery</title>
<script>
  // Apply the saved (or system) theme before first paint → no flash
  try { var t = localStorage.getItem('gallery.theme');
    if (t ? t === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches) document.documentElement.classList.add('dark');
  } catch (e) { document.documentElement.classList.add('dark'); }
</script>
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    darkMode: 'class',
    theme: { extend: {
      colors: {
        bg:    'rgb(var(--bg) / <alpha-value>)',
        panel: 'rgb(var(--panel) / <alpha-value>)',
        fg:    'rgb(var(--fg) / <alpha-value>)',
        mute:  'rgb(var(--mute) / <alpha-value>)',
        ink:   'rgb(var(--ink) / <alpha-value>)',   /* white in dark mode, slate in light mode */
      },
      fontFamily: { sans: ['Inter', 'ui-sans-serif', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'] },
      keyframes: {
        fadeUp:  { '0%': { opacity: 0, transform: 'translateY(10px) scale(.98)' }, '100%': { opacity: 1, transform: 'none' } },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
        pop:     { '0%': { opacity: 0, transform: 'scale(.96)' }, '100%': { opacity: 1, transform: 'scale(1)' } },
      },
      animation: { fadeUp: 'fadeUp .5s cubic-bezier(.2,.7,.2,1) both', pop: 'pop .18s ease-out both' },
    } }
  };
</script>
<link href="https://cdn.jsdelivr.net/npm/cropperjs@1.6.1/dist/cropper.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/cropperjs@1.6.1/dist/cropper.min.js"></script>
<style>
  :root {
    --cell: 220px;
    --bg: 246 247 251; --panel: 255 255 255; --fg: 20 22 34; --mute: 96 102 120; --ink: 15 23 42;
    --glass: rgba(255,255,255,.72);
    --a1: rgba(99,102,241,.16); --a2: rgba(217,70,239,.10); --a3: rgba(6,182,212,.12);
    --sb: #cfd3df; color-scheme: light;
  }
  :root.dark {
    --bg: 7 7 11; --panel: 23 23 28; --fg: 232 232 238; --mute: 160 160 175; --ink: 255 255 255;
    --glass: rgba(255,255,255,.04);
    --a1: rgba(99,102,241,.22); --a2: rgba(217,70,239,.14); --a3: rgba(6,182,212,.12);
    --sb: #2a2a35; color-scheme: dark;
  }
  .glass { background: var(--glass); border: 1px solid rgb(var(--ink) / .1); backdrop-filter: blur(16px); }
  .media-grid { display: grid; gap: 14px; grid-template-columns: repeat(auto-fill, minmax(var(--cell), 1fr)); }

  /* Aurora backdrop: plain radial gradients (no blur filters) so it costs almost nothing */
  .aurora {
    position: fixed; inset: 0; z-index: -1; pointer-events: none;
    background:
      radial-gradient(900px 500px at 12% -8%,  var(--a1), transparent 60%),
      radial-gradient(800px 480px at 95% 5%,   var(--a2), transparent 60%),
      radial-gradient(900px 600px at 50% 110%, var(--a3), transparent 60%),
      rgb(var(--bg));
  }

  /* Cards: skip rendering work for off-screen ones — keeps huge folders smooth */
  .card { content-visibility: auto; contain-intrinsic-size: var(--cell) var(--cell); aspect-ratio: 1/1; }
  .card .thumb { opacity: 0; transition: opacity .45s ease, transform .6s cubic-bezier(.2,.7,.2,1); }
  .card.ready .thumb { opacity: 1; }
  .card:hover .thumb { transform: scale(1.07); }

  /* Shimmer placeholder only while a thumbnail is actually being fetched */
  .card.loading::after {
    content: ''; position: absolute; inset: 0; transform: translateX(-100%);
    background: linear-gradient(90deg, transparent, rgba(255,255,255,.06), transparent);
    animation: shimmer 1.2s infinite;
  }
  .card.ready::after { display: none; }

  ::-webkit-scrollbar { width: 10px; height: 10px; }
  ::-webkit-scrollbar-thumb { background: var(--sb); border-radius: 99px; border: 2px solid rgb(var(--bg)); }
  @media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
</style>
<style type="text/tailwindcss">
  .toolbtn { @apply grid place-items-center w-9 h-9 rounded-xl text-fg hover:bg-ink/10 active:scale-95 transition; }
  .navbtn  { @apply absolute top-1/2 -translate-y-1/2 z-10 grid place-items-center w-14 h-14 rounded-full bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 shadow-2xl shadow-black/40 ring-4 ring-bg/60 hover:!bg-indigo-500 hover:!text-white hover:scale-110 active:scale-95 transition; }
  .chip    { @apply px-3 py-1.5 rounded-full text-xs font-medium text-mute hover:text-fg transition; }
  .chip.active { @apply bg-ink/10 text-fg; }

</style>
</head>
<body class="font-sans bg-bg text-fg min-h-screen antialiased selection:bg-indigo-500/30">
<div class="aurora"></div>

<?php if (!gd_available() && !class_exists('Imagick')): ?>
<div class="bg-amber-500/15 border-b border-amber-500/30 text-amber-700 dark:text-amber-300 text-sm px-4 py-2.5 text-center">
  <b>PHP GD extension is disabled</b> — thumbnails, rotate and crop won’t work. Open <code>C:\xampp\php\php.ini</code>, remove the <code>;</code> before <code>extension=gd</code>, then restart Apache.
</div>
<?php endif; ?>
<!-- ============ Header ============ -->
<header class="sticky top-0 z-30 border-b border-ink/10 bg-bg/70 backdrop-blur-xl">
  <div class="max-w-[1600px] mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center gap-x-4 gap-y-3">

    <div class="flex items-center gap-3 min-w-0 flex-1">
      <?php if ($currentPath !== ''): ?>
        <a href="?path=<?= urlencode($parentPath) ?>" title="Back"
           class="grid place-items-center w-9 h-9 rounded-xl bg-ink/5 hover:bg-ink/10 border border-ink/10 text-fg/80 transition shrink-0">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
        </a>
      <?php endif; ?>

      <a href="?" class="flex items-center gap-2.5 shrink-0 group">
        <span class="grid place-items-center w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-lg shadow-indigo-500/30 group-hover:rotate-6 transition">
          <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="1.7" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909M3 6.75a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 6.75v10.5a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 17.25V6.75z"/></svg>
        </span>
        <span class="text-lg font-bold tracking-tight bg-gradient-to-r from-fg to-mute bg-clip-text text-transparent">Gallery</span>
      </a>

      <?php foreach ($crumbs as $i => [$label, $p]): ?>
        <svg class="w-4 h-4 text-mute/50 shrink-0 hidden sm:block" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg>
        <a href="?path=<?= urlencode($p) ?>"
           class="hidden sm:block truncate max-w-[160px] text-sm <?= $i === count($crumbs) - 1 ? 'text-fg font-medium' : 'text-mute hover:text-fg' ?> transition"><?= e($label) ?></a>
      <?php endforeach; ?>
    </div>

    <?php if (!empty($listing['files'])): ?>
    <div class="flex items-center gap-2 sm:gap-3 flex-wrap">
      <label class="relative">
        <svg class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-mute/80 pointer-events-none" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-4.35-4.35M17 10.5a6.5 6.5 0 11-13 0 6.5 6.5 0 0113 0z"/></svg>
        <input id="search" type="search" placeholder="Search…" autocomplete="off"
               class="w-36 sm:w-48 focus:w-56 transition-[width] pl-9 pr-3 py-2 rounded-xl bg-ink/5 border border-ink/10 text-sm placeholder:text-mute/80 outline-none focus:border-indigo-400/60 focus:ring-4 focus:ring-indigo-500/10">
      </label>

      <div id="filters" class="flex items-center p-1 rounded-full bg-ink/5 border border-ink/10">
        <button class="chip active" data-filter="all">All <span class="opacity-60" id="cntAll"><?= count($listing['files']) ?></span></button>
        <button class="chip" data-filter="image">Photos <span class="opacity-60" id="cntImage"><?= $photoCount ?></span></button>
        <button class="chip" data-filter="video">Videos <span class="opacity-60" id="cntVideo"><?= $videoCount ?></span></button>
      </div>

      <div id="density" class="hidden md:flex items-center p-1 rounded-full bg-ink/5 border border-ink/10" title="Thumbnail size">
        <button class="chip" data-cell="150">S</button>
        <button class="chip active" data-cell="220">M</button>
        <button class="chip" data-cell="320">L</button>
      </div>
    </div>
    <?php endif; ?>

    <button id="themeBtn" title="Toggle light / dark" aria-label="Toggle theme"
            class="grid place-items-center w-9 h-9 rounded-xl bg-ink/5 hover:bg-ink/10 border border-ink/10 text-fg transition active:scale-95">
      <svg class="w-[18px] h-[18px] hidden dark:block" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z"/></svg>
      <svg class="w-[18px] h-[18px] dark:hidden" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z"/></svg>
    </button>
  </div>
</header>

<main class="max-w-[1600px] mx-auto px-4 sm:px-6 py-8">

  <?php if (empty($listing['folders']) && empty($listing['files'])): ?>
    <div class="glass rounded-3xl text-center py-24 px-6 animate-fadeUp max-w-xl mx-auto mt-10">
      <div class="mx-auto mb-5 grid place-items-center w-16 h-16 rounded-2xl bg-ink/5 text-mute/80">
        <svg class="w-8 h-8" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 9.776c.112-.017.227-.026.344-.026h15.812c.117 0 .232.009.344.026m-16.5 0a2.25 2.25 0 00-1.883 2.542l.857 6a2.25 2.25 0 002.227 1.932H19.05a2.25 2.25 0 002.227-1.932l.857-6a2.25 2.25 0 00-1.883-2.542m-16.5 0V6A2.25 2.25 0 016 3.75h3.879a1.5 1.5 0 011.06.44l2.122 2.12a1.5 1.5 0 001.06.44H18A2.25 2.25 0 0120.25 9v.776"/></svg>
      </div>
      <p class="text-lg text-fg font-medium">Nothing here yet</p>
      <p class="text-sm mt-2 text-mute/80">This folder is empty or the path was not found.<br>Check <code class="text-fg/80">MEDIA_ROOT</code> in config.php.</p>
    </div>
  <?php endif; ?>

  <?php if (!empty($listing['folders'])): ?>
  <section class="mb-10">
    <h2 class="text-xs uppercase tracking-[.18em] text-mute/80 mb-4 font-semibold">Folders</h2>
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-3">
      <?php foreach ($listing['folders'] as $i => $f): ?>
        <a href="?path=<?= urlencode($f['path']) ?>" style="animation-delay: <?= min($i * 30, 400) ?>ms"
           class="animate-fadeUp group flex items-center gap-3 p-3.5 rounded-2xl glass hover:bg-ink/[.08] hover:border-amber-400/30 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-amber-500/5 transition duration-200">
          <span class="grid place-items-center w-11 h-11 rounded-xl bg-gradient-to-br from-amber-300 to-orange-500 shadow-md shadow-orange-500/20 group-hover:scale-110 group-hover:-rotate-3 transition shrink-0">
            <svg class="w-6 h-6 text-white/95" fill="currentColor" viewBox="0 0 24 24"><path d="M19.5 21a3 3 0 003-3v-4.5a3 3 0 00-3-3h-15a3 3 0 00-3 3V18a3 3 0 003 3h15zM1.5 10.146V6a3 3 0 013-3h5.379a2.25 2.25 0 011.59.659l2.122 2.121c.14.141.331.22.53.22H19.5a3 3 0 013 3v1.146A4.483 4.483 0 0019.5 9h-15a4.483 4.483 0 00-3 1.146z"/></svg>
          </span>
          <span class="text-sm truncate text-fg group-hover:text-fg"><?= e($f['name']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if (!empty($listing['files'])): ?>
  <section>
    <div class="flex items-baseline justify-between mb-4">
      <h2 class="text-xs uppercase tracking-[.18em] text-mute/80 font-semibold">Media</h2>
      <span id="shownLabel" class="text-xs text-mute/80"></span>
    </div>

    <div class="media-grid" id="mediaGrid">
      <?php foreach ($listing['files'] as $i => $file):
        $thumbUrl = 'thumb.php?path=' . urlencode($file['path']) . '&m=' . $file['mtime'];
        $vidUrl   = 'serve.php?path=' . urlencode($file['path']) . '&m=' . $file['mtime'];
      ?>
        <div class="card grid-item group relative rounded-2xl overflow-hidden bg-panel ring-1 ring-ink/10 hover:ring-indigo-400/50 shadow-lg shadow-slate-900/10 dark:shadow-black/30 hover:shadow-2xl hover:shadow-indigo-500/10 hover:-translate-y-1 cursor-pointer transition duration-300 <?= $i < 30 ? 'animate-fadeUp' : '' ?>"
             style="animation-delay: <?= min($i * 25, 500) ?>ms"
             data-path="<?= e($file['path']) ?>"
             data-type="<?= $file['type'] ?>"
             data-name="<?= e($file['name']) ?>"
             data-size="<?= e(human_size($file['size'])) ?>"
             data-mtime="<?= $file['mtime'] ?>">

          <?php if ($file['type'] === 'image'): ?>
            <img data-src="<?= e($thumbUrl) ?>" data-full="<?= e($vidUrl) ?>" alt="" decoding="async" draggable="false"
                 class="thumb lazy-thumb absolute inset-0 w-full h-full object-cover">
          <?php else: ?>
            <video data-src="<?= e($vidUrl) ?>" preload="none" muted loop playsinline disablepictureinpicture
                   class="thumb lazy-thumb absolute inset-0 w-full h-full object-cover"></video>
          <?php endif; ?>

          <!-- name + size on hover -->
          <div class="absolute inset-x-0 bottom-0 p-3 pt-10 bg-gradient-to-t from-black/85 via-black/40 to-transparent opacity-0 group-hover:opacity-100 translate-y-1 group-hover:translate-y-0 transition duration-300">
            <p class="text-xs font-medium truncate text-white"><?= e($file['name']) ?></p>
            <p class="text-[11px] text-neutral-300/80"><?= e(human_size($file['size'])) ?></p>
          </div>

          <?php if ($file['type'] === 'video'): ?>
            <div class="absolute top-2 left-2 right-2 flex items-center justify-between pointer-events-none">
              <span class="dur hidden px-2 py-0.5 rounded-full bg-black/55 backdrop-blur text-[11px] font-medium text-white tabular-nums"></span>
              <span class="ml-auto grid place-items-center w-7 h-7 rounded-full bg-black/55 backdrop-blur ring-1 ring-white/20">
                <svg class="w-3.5 h-3.5 text-white translate-x-px" fill="currentColor" viewBox="0 0 24 24"><path d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653z"/></svg>
              </span>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>

    <div id="noResults" class="hidden text-center py-20 text-mute/80 text-sm">No files match your search.</div>
  </section>
  <?php endif; ?>

</main>

<!-- ============ Viewer ============ -->
<div id="viewer" class="fixed inset-0 z-50 bg-bg hidden flex-col">
  <div class="absolute inset-x-0 top-0 z-20 flex items-center justify-between gap-3 px-3 sm:px-6 py-3 border-b border-ink/10 bg-bg/75 backdrop-blur-xl">
    <div class="flex items-center gap-3 min-w-0">
      <span class="grid place-items-center w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-lg shadow-indigo-500/30 shrink-0">
        <svg id="icoImg" class="w-5 h-5 text-white" fill="none" stroke="currentColor" stroke-width="1.7" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909M3 6.75a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 6.75v10.5a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 17.25V6.75z"/></svg>
        <svg id="icoVid" class="w-5 h-5 text-white hidden" fill="currentColor" viewBox="0 0 24 24"><path d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653z"/></svg>
      </span>
      <div class="min-w-0">
        <p id="viewerTitle" class="text-sm font-semibold text-fg truncate"></p>
        <p id="viewerMeta" class="text-xs text-mute"></p>
      </div>
    </div>
    <div class="flex items-center gap-0.5 p-1 rounded-2xl bg-ink/5 border border-ink/10">
      <span id="zoomLabel" class="text-xs font-medium text-mute w-12 text-center select-none image-only-tool hidden"></span>
      <button id="btnRotateLeft" title="Rotate left" class="toolbtn image-only-tool"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3"/></svg></button>
      <button id="btnRotateRight" title="Rotate right" class="toolbtn image-only-tool"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 15l6-6m0 0l-6-6m6 6H9a6 6 0 000 12h3"/></svg></button>
      <button id="btnCrop" title="Crop" class="toolbtn image-only-tool"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6.13 1L6 16a2 2 0 002 2h15M1 6.13L16 6a2 2 0 012 2v15"/></svg></button>
      <a id="btnDownload" title="Download" download class="toolbtn"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12M12 16.5V3"/></svg></a>
      <button id="btnDelete" title="Delete" class="toolbtn !text-red-400 hover:!bg-red-500/15"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"/></svg></button>
      <div class="w-px h-6 bg-ink/15 mx-1"></div>
      <button id="btnClose" title="Close (Esc)" class="toolbtn"><svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>
    </div>
  </div>

  <button id="btnPrev" title="Previous (←)" aria-label="Previous" class="navbtn left-3 sm:left-5"><svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg></button>
  <button id="btnNext" title="Next (→)" aria-label="Next" class="navbtn right-3 sm:right-5"><svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/></svg></button>

  <div id="viewerStage" class="flex-1 flex items-center justify-center overflow-hidden relative px-4 pt-[88px] pb-8 md:px-20 select-none">
    <div id="imgWrap" class="hidden w-full h-full min-h-0 min-w-0 flex items-center justify-center">
      <img id="viewerImg" alt="" class="max-w-full max-h-full hidden cursor-grab rounded-xl shadow-2xl shadow-slate-900/20 dark:shadow-black" style="transform-origin: center center;">
    </div>
    <div id="videoWrap" class="hidden max-w-full max-h-full rounded-xl overflow-hidden shadow-2xl shadow-slate-900/20 dark:shadow-black bg-black">
      <video id="viewerVideo" class="block max-w-full max-h-[80vh]" controls playsinline></video>
    </div>
  </div>

  <div id="cropBar" class="hidden items-center justify-center gap-3 p-3 border-t border-ink/10 bg-bg/80 backdrop-blur">
    <button id="cropApply" class="px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 hover:brightness-110 text-white text-sm font-medium transition">Apply crop</button>
    <button id="cropCancel" class="px-5 py-2 rounded-xl bg-ink/10 hover:bg-ink/15 text-fg text-sm font-medium transition">Cancel</button>
  </div>
</div>

<!-- Confirm delete -->
<div id="confirmModal" class="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm hidden items-center justify-center p-4">
  <div class="animate-pop bg-panel border border-ink/10 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl">
    <div class="mx-auto mb-4 grid place-items-center w-12 h-12 rounded-2xl bg-red-500/15 text-red-400">
      <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg>
    </div>
    <p class="text-fg font-medium mb-1">Delete this file?</p>
    <p class="text-sm text-mute mb-5">It will be permanently removed and this can’t be undone.</p>
    <div class="flex justify-center gap-3">
      <button id="confirmNo" class="px-5 py-2 rounded-xl bg-ink/10 hover:bg-ink/15 text-fg text-sm font-medium transition">Cancel</button>
      <button id="confirmYes" class="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm font-medium transition">Delete</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div id="toast" class="fixed bottom-24 left-1/2 -translate-x-1/2 z-[70] hidden px-4 py-2.5 rounded-xl text-sm font-medium shadow-xl text-white"></div>

<!-- Context menu -->
<div id="contextMenu" class="fixed z-[80] hidden glass !bg-panel/95 rounded-2xl shadow-2xl py-1.5 min-w-[200px] text-sm animate-pop">
  <button id="ctxOpen" class="w-full text-left px-4 py-2.5 hover:bg-ink/10 text-fg flex items-center gap-2.5 transition">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z"/><path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
    Open
  </button>
  <div class="h-px bg-ink/10 my-1"></div>
  <button id="ctxDelete" class="w-full text-left px-4 py-2.5 hover:bg-red-500/15 text-red-400 flex items-center gap-2.5 transition">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"/></svg>
    Delete
  </button>
</div>

<script>
const $ = (id) => document.getElementById(id);
const grid = $('mediaGrid');
const lsGet = (k, d) => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

/* =====================================================================
   Thumbnail loader — light on the browser AND the server
   • Only items near the viewport are fetched (IntersectionObserver)
   • At most MAX_PARALLEL thumbnails load at once, so the PHP server is
     never flooded with dozens of decode jobs
   • Items scrolled past before their turn are dropped from the queue
   • Image thumbs are tiny WebP/JPEG with a far-future cache (mtime in URL);
     video thumbs reuse the browser's own first-frame decode.
   ===================================================================== */
const MAX_PARALLEL = 6;
let active = 0;
const queue = [];

function pump() {
  while (active < MAX_PARALLEL && queue.length) startLoad(queue.shift());
}

function startLoad(el) {
  const card = el.closest('.card');
  active++;
  let finished = false;
  const done = () => {
    if (finished) return; finished = true;
    active--; card.classList.remove('loading'); card.classList.add('ready'); pump();
  };
  card.classList.add('loading');
  el.addEventListener('error', () => {
    // Thumbnail endpoint failed → fall back to the original file once, so the grid never shows broken images
    if (el.tagName === 'IMG' && el.dataset.full && !el.dataset.fb) {
      el.dataset.fb = '1'; console.warn('thumb.php failed, using original for', card.dataset.name); el.src = el.dataset.full;
    } else done();
  });

  if (el.tagName === 'VIDEO') {
    el.addEventListener('loadeddata', done, { once: true });
    el.addEventListener('loadedmetadata', () => {
      const d = card.querySelector('.dur');
      if (d && isFinite(el.duration)) { d.textContent = fmtTime(el.duration); d.classList.remove('hidden'); }
    }, { once: true });
    el.preload = 'metadata';
    el.src = el.dataset.src + '#t=0.1';   // t=0.1 → avoids a black first frame
  } else {
    el.addEventListener('load', done);
    el.src = el.dataset.src;
  }
  el.removeAttribute('data-src');
}

const lazyObserver = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    const el = entry.target;
    if (entry.isIntersecting) {
      if (el.dataset.src) { queue.push(el); }
    } else {
      const i = queue.indexOf(el);            // scrolled away before its turn
      if (i > -1) queue.splice(i, 1);
    }
  }
  pump();
}, { rootMargin: '500px 0px', threshold: 0.01 });

function fmtTime(s) {
  s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
  return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(sec).padStart(2, '0');
}

if (grid) {
  grid.querySelectorAll('.lazy-thumb[data-src]').forEach(el => lazyObserver.observe(el));

  // Hover preview for videos (desktop only) — plays the already-loaded stream silently
  if (matchMedia('(hover: hover)').matches) {
    grid.addEventListener('mouseover', (e) => {
      const card = e.target.closest('.card[data-type="video"]');
      if (!card || card.contains(e.relatedTarget)) return;
      const v = card.querySelector('video');
      if (v && card.classList.contains('ready')) v.play().catch(() => {});
    });
    grid.addEventListener('mouseout', (e) => {
      const card = e.target.closest('.card[data-type="video"]');
      if (!card || card.contains(e.relatedTarget)) return;
      const v = card.querySelector('video');
      if (v) { v.pause(); try { v.currentTime = 0.1; } catch {} }
    });
  }
}

/* ============================ Theme ============================ */
$('themeBtn').addEventListener('click', () => {
  const dark = document.documentElement.classList.toggle('dark');
  lsSet('gallery.theme', dark ? 'dark' : 'light');
});

/* ============================ Filters / search / density ============================ */
let filter = 'all', query = '';
function applyFilter() {
  if (!grid) return;
  let shown = 0;
  grid.querySelectorAll('.card').forEach(c => {
    const ok = (filter === 'all' || c.dataset.type === filter) && (!query || c.dataset.name.toLowerCase().includes(query));
    c.classList.toggle('hidden', !ok);
    if (ok) shown++;
  });
  $('noResults').classList.toggle('hidden', shown > 0);
  $('shownLabel').textContent = shown === grid.children.length ? '' : `${shown} shown`;
}
function updateCounts() {
  if (!grid) return;
  const imgs = grid.querySelectorAll('.card[data-type="image"]').length;
  const vids = grid.querySelectorAll('.card[data-type="video"]').length;
  $('cntAll').textContent = imgs + vids; $('cntImage').textContent = imgs; $('cntVideo').textContent = vids;
}
if ($('filters')) {
  $('filters').addEventListener('click', (e) => {
    const b = e.target.closest('[data-filter]'); if (!b) return;
    filter = b.dataset.filter;
    $('filters').querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c === b));
    applyFilter();
  });
  let t; $('search').addEventListener('input', (e) => {
    clearTimeout(t); t = setTimeout(() => { query = e.target.value.trim().toLowerCase(); applyFilter(); }, 120);
  });
  const setCell = (px) => {
    document.documentElement.style.setProperty('--cell', px + 'px');
    $('density').querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c.dataset.cell === String(px)));
    lsSet('gallery.cell', px);
  };
  $('density').addEventListener('click', (e) => { const b = e.target.closest('[data-cell]'); if (b) setCell(b.dataset.cell); });
  setCell(lsGet('gallery.cell', '220'));
}

/* ============================ Viewer ============================ */
const viewer = $('viewer'), viewerStage = $('viewerStage'), viewerImg = $('viewerImg');
const videoWrap = $('videoWrap'), viewerVideo = $('viewerVideo');
const cropBar = $('cropBar'), confirmModal = $('confirmModal'), toast = $('toast');
const contextMenu = $('contextMenu'), zoomLabel = $('zoomLabel');

let currentItem = null;    // the grid card being viewed / acted on
let cropper = null;
let toastTimer;
const curPath = () => currentItem.dataset.path;
const curType = () => currentItem.dataset.type;

// ---- zoom + pan (clamped to the image bounds) ----
let previewRot = 0, previewScale = 1;
let zoomLevel = 1, panX = 0, panY = 0, isPanning = false, panStartX = 0, panStartY = 0, dragStartX = 0, dragStartY = 0;

function clampPan() {
  const r = viewerStage.getBoundingClientRect();
  const maxX = Math.max(0, (viewerImg.offsetWidth * zoomLevel - r.width) / 2);
  const maxY = Math.max(0, (viewerImg.offsetHeight * zoomLevel - r.height) / 2);
  panX = Math.min(maxX, Math.max(-maxX, panX));
  panY = Math.min(maxY, Math.max(-maxY, panY));
}
function applyTransform() {
  clampPan();
  viewerImg.style.transform = `translate(${panX}px, ${panY}px) scale(${zoomLevel}) rotate(${previewRot}deg) scale(${previewScale})`;
  zoomLabel.textContent = Math.round(zoomLevel * 100) + '%';
  viewerImg.style.cursor = zoomLevel > 1 ? 'grab' : 'default';
}
function resetZoom() { zoomLevel = 1; panX = 0; panY = 0; applyTransform(); }
function setZoom(newZoom, px = null, py = null) {
  newZoom = Math.min(Math.max(newZoom, 1), 6);
  const r = viewerStage.getBoundingClientRect();
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  if (px === null) { px = cx; py = cy; }
  const pointX = (px - cx - panX) / zoomLevel, pointY = (py - cy - panY) / zoomLevel;
  zoomLevel = newZoom;
  panX = px - cx - pointX * newZoom;
  panY = py - cy - pointY * newZoom;
  applyTransform();
}

viewerStage.addEventListener('wheel', (e) => {
  if (!currentItem || curType() !== 'image' || viewerImg.classList.contains('hidden') || !cropBar.classList.contains('hidden')) return;
  e.preventDefault();
  setZoom(zoomLevel + (e.deltaY > 0 ? -0.15 : 0.15), e.clientX, e.clientY);
}, { passive: false });

viewerImg.addEventListener('mousedown', (e) => {
  if (zoomLevel <= 1 || !cropBar.classList.contains('hidden')) return;
  e.preventDefault();
  isPanning = true; dragStartX = e.clientX; dragStartY = e.clientY; panStartX = panX; panStartY = panY;
  viewerImg.style.cursor = 'grabbing';
});
window.addEventListener('mousemove', (e) => {
  if (!isPanning) return;
  panX = panStartX + (e.clientX - dragStartX); panY = panStartY + (e.clientY - dragStartY);
  applyTransform();
});
window.addEventListener('mouseup', () => { if (isPanning) { isPanning = false; if (zoomLevel > 1) viewerImg.style.cursor = 'grab'; } });
window.addEventListener('blur', () => { isPanning = false; });
viewerImg.addEventListener('dblclick', (e) => {
  if (!cropBar.classList.contains('hidden')) return;
  zoomLevel > 1 ? resetZoom() : setZoom(2.5, e.clientX, e.clientY);
});

// Swipe left/right on touch screens to navigate
let touchX = null;
viewerStage.addEventListener('touchstart', (e) => { touchX = (e.touches.length === 1 && zoomLevel === 1) ? e.touches[0].clientX : null; }, { passive: true });
viewerStage.addEventListener('touchend', (e) => {
  if (touchX === null) return;
  const dx = e.changedTouches[0].clientX - touchX; touchX = null;
  if (Math.abs(dx) > 60) navigate(dx < 0 ? 1 : -1);
}, { passive: true });

function showToast(msg, ok = true) {
  toast.textContent = msg;
  toast.className = 'fixed bottom-24 left-1/2 -translate-x-1/2 z-[70] px-4 py-2.5 rounded-xl text-sm font-medium shadow-xl text-white animate-pop ' + (ok ? 'bg-emerald-600' : 'bg-red-600');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add('hidden'), ok ? 2500 : 7000);
}

const visibleItems = () => [...grid.querySelectorAll('.card:not(.hidden)')];

function openViewer(item) {
  if (cropper) { cropper.destroy(); cropper = null; }
  currentItem = item;
  const type = item.dataset.type, path = item.dataset.path, m = item.dataset.mtime || Date.now();

  const list = visibleItems(), idx = list.indexOf(item);
  $('viewerTitle').textContent = item.dataset.name;
  $('viewerMeta').textContent = `${idx + 1} / ${list.length} · ${item.dataset.size}`;
  $('btnPrev').classList.toggle('hidden', list.length < 2);
  $('btnNext').classList.toggle('hidden', list.length < 2);
  $('btnDownload').href = 'serve.php?path=' + encodeURIComponent(path);
  $('btnDownload').setAttribute('download', item.dataset.name);

  $('icoImg').classList.toggle('hidden', type !== 'image'); $('icoVid').classList.toggle('hidden', type === 'image');
  viewer.classList.remove('hidden'); viewer.classList.add('flex');
  document.body.style.overflow = 'hidden';

  viewerImg.classList.add('hidden'); $('imgWrap').classList.add('hidden'); videoWrap.classList.add('hidden');
  viewerVideo.pause();
  cropBar.classList.add('hidden'); cropBar.classList.remove('flex');
  document.querySelectorAll('.image-only-tool').forEach(el => el.classList.toggle('hidden', type !== 'image'));
  resetZoom();

  if (type === 'image') {
    viewerVideo.removeAttribute('src');
    viewerImg.src = 'serve.php?path=' + encodeURIComponent(path) + '&m=' + m;
    viewerImg.classList.remove('hidden'); $('imgWrap').classList.remove('hidden');
  } else {
    viewerVideo.src = 'serve.php?path=' + encodeURIComponent(path);
    videoWrap.classList.remove('hidden');
  }
}

function closeViewer() {
  if (pendingItem) flushRotate();
  resetPreviewNow();
  if (cropper) { cropper.destroy(); cropper = null; }
  viewer.classList.add('hidden'); viewer.classList.remove('flex');
  document.body.style.overflow = '';
  viewerVideo.pause(); viewerVideo.removeAttribute('src'); viewerVideo.load();
  resetZoom();
}

function navigate(dir) {
  if (!currentItem || !cropBar.classList.contains('hidden')) return;
  if (pendingItem) flushRotate();
  resetPreviewNow();
  const list = visibleItems(); if (list.length < 2) return;
  const i = list.indexOf(currentItem);
  openViewer(list[(i + dir + list.length) % list.length]);
}
$('btnPrev').addEventListener('click', () => navigate(-1));
$('btnNext').addEventListener('click', () => navigate(1));

if (grid) grid.addEventListener('click', (e) => { const item = e.target.closest('.card'); if (item) openViewer(item); });

// ---- context menu ----
function showContextMenu(x, y) {
  contextMenu.classList.remove('hidden');
  contextMenu.style.left = Math.min(x, innerWidth - 220) + 'px';
  contextMenu.style.top = Math.min(y, innerHeight - 120) + 'px';
}
const hideContextMenu = () => contextMenu.classList.add('hidden');

if (grid) grid.addEventListener('contextmenu', (e) => {
  const item = e.target.closest('.card'); if (!item) return;
  e.preventDefault(); currentItem = item; showContextMenu(e.clientX, e.clientY);
});
document.addEventListener('click', (e) => { if (!contextMenu.contains(e.target)) hideContextMenu(); });
document.addEventListener('scroll', hideContextMenu, true);
window.addEventListener('resize', hideContextMenu);

$('ctxOpen').addEventListener('click', () => { hideContextMenu(); if (currentItem) openViewer(currentItem); });
$('ctxDelete').addEventListener('click', () => { hideContextMenu(); openConfirm(); });

function openConfirm() { confirmModal.classList.remove('hidden'); confirmModal.classList.add('flex'); }
function closeConfirm() { confirmModal.classList.add('hidden'); confirmModal.classList.remove('flex'); }

$('btnClose').addEventListener('click', closeViewer);
viewerStage.addEventListener('click', (e) => { if (e.target === viewerStage) closeViewer(); });

// ---- API actions ----
async function callApi(action, extra = {}, item = currentItem) {
  const body = new URLSearchParams({ action, path: item.dataset.path, ...extra });
  let res, text;
  try { res = await fetch('api.php', { method: 'POST', body }); text = await res.text(); }
  catch { return { ok: false, message: 'Could not reach the server.' }; }
  try { return JSON.parse(text); }
  catch {
    console.error('api.php returned:', text);
    return { ok: false, message: `Server error (${res.status}): ` + (text.replace(/<[^>]+>/g, ' ').trim().slice(0, 160) || 'empty response') };
  }
}

function applyServerUpdate(r, item = currentItem, then = null) {
  const m = r.mtime || Date.now();
  item.dataset.mtime = m;
  const path = item.dataset.path;
  const th = item.querySelector('img.thumb');
  if (th) { th.removeAttribute('data-src'); th.src = 'thumb.php?path=' + encodeURIComponent(path) + '&m=' + m; }
  if (item === currentItem && !viewer.classList.contains('hidden')) {
    viewerImg.onload = () => { viewerImg.onload = null; then && then(); };
    viewerImg.src = 'serve.php?path=' + encodeURIComponent(path) + '&m=' + m;
  } else if (then) then();
}

// Rotation is shown instantly in the browser; the server saves it in the background
// (several clicks in a row are merged into a single save).
let pendingDeg = 0, rotTimer = null, pendingItem = null, saving = false;

function updatePreviewScale() {
  const box = $('imgWrap').getBoundingClientRect();
  const w = viewerImg.offsetWidth, h = viewerImg.offsetHeight;
  const quarter = Math.abs(Math.round(previewRot / 90)) % 2 === 1;
  previewScale = quarter ? Math.min(1, box.width / h, box.height / w) : 1;
}

function showRotationPreview() {
  updatePreviewScale();
  viewerImg.style.transition = 'transform .25s cubic-bezier(.2,.7,.2,1)';
  zoomLevel = 1; panX = 0; panY = 0;
  applyTransform();
}

// The saved image has been reloaded: drop the part of the preview that is now baked into the file
function settlePreview(raw) {
  viewerImg.style.transition = 'none';
  previewRot -= raw;
  updatePreviewScale();
  applyTransform();
  requestAnimationFrame(() => { viewerImg.style.transition = ''; });
}

function resetPreviewNow() {
  viewerImg.style.transition = 'none';
  previewRot = 0; previewScale = 1;
  applyTransform();
}

async function flushRotate() {
  clearTimeout(rotTimer); rotTimer = null;
  if (!pendingItem) return;
  if (saving) { rotTimer = setTimeout(flushRotate, 150); return; }   // one save at a time
  const item = pendingItem, raw = pendingDeg, deg = ((raw % 360) + 360) % 360;
  pendingDeg = 0; pendingItem = null;
  if (deg === 0) { if (item === currentItem) settlePreview(raw); return; }
  saving = true;
  const r = await callApi('rotate', { degrees: deg }, item);
  saving = false;
  if (r.ok) applyServerUpdate(r, item, () => { if (item === currentItem) settlePreview(raw); });
  else { if (item === currentItem) settlePreview(raw); showToast(r.message, false); }
}

function rotate(deg) {
  if (!currentItem) return;
  if (pendingItem && pendingItem !== currentItem) flushRotate();
  pendingItem = currentItem;
  pendingDeg += deg; previewRot += deg;
  showRotationPreview();
  clearTimeout(rotTimer); rotTimer = setTimeout(flushRotate, 450);
}
$('btnRotateLeft').addEventListener('click', () => rotate(-90));
$('btnRotateRight').addEventListener('click', () => rotate(90));

$('btnCrop').addEventListener('click', async () => {
  if (pendingItem) flushRotate();
  while (pendingItem || saving) await new Promise(r => setTimeout(r, 80));
  cropBar.classList.remove('hidden'); cropBar.classList.add('flex');
  if (cropper) cropper.destroy();
  resetZoom();
  $('btnPrev').classList.add('hidden'); $('btnNext').classList.add('hidden');
  cropper = new Cropper(viewerImg, { viewMode: 1, autoCropArea: 1, background: false, guides: true, movable: false, zoomable: false, responsive: true });
});
function endCrop() {
  if (cropper) { cropper.destroy(); cropper = null; }
  if (visibleItems().length > 1) { $('btnPrev').classList.remove('hidden'); $('btnNext').classList.remove('hidden'); }
  cropBar.classList.add('hidden'); cropBar.classList.remove('flex');
}
$('cropCancel').addEventListener('click', endCrop);
$('cropApply').addEventListener('click', async () => {
  if (!cropper) return;
  const d = cropper.getData(true);
  endCrop();
  const r = await callApi('crop', { x: d.x, y: d.y, w: d.width, h: d.height });
  if (r.ok) applyServerUpdate(r); else showToast(r.message, false);
});

$('btnDelete').addEventListener('click', openConfirm);
$('confirmNo').addEventListener('click', closeConfirm);
confirmModal.addEventListener('click', (e) => { if (e.target === confirmModal) closeConfirm(); });
$('confirmYes').addEventListener('click', async () => {
  const item = currentItem;
  const r = await callApi('delete');
  closeConfirm();
  if (!r.ok) return showToast(r.message, false);
  showToast(r.message);

  const wasViewing = !viewer.classList.contains('hidden');
  const list = visibleItems(), i = list.indexOf(item);
  const next = list.length > 1 ? list[(i + 1) % list.length] : null;
  lazyObserver.unobserve(item.querySelector('.lazy-thumb'));
  item.remove();
  updateCounts(); applyFilter();
  if (wasViewing) { next && next !== item ? openViewer(next) : closeViewer(); }
});

document.addEventListener('keydown', (e) => {
  if (e.target.matches('input')) { if (e.key === 'Escape') e.target.blur(); return; }
  if (!confirmModal.classList.contains('hidden')) { if (e.key === 'Escape') closeConfirm(); return; }
  if (viewer.classList.contains('hidden')) {
    if (e.key === '/') { const s = $('search'); if (s) { e.preventDefault(); s.focus(); } }
    return;
  }
  if (e.key === 'Escape') { cropper ? endCrop() : closeViewer(); }
  else if (e.key === 'ArrowLeft') navigate(-1);
  else if (e.key === 'ArrowRight') navigate(1);
});
</script>
</body>
</html>
