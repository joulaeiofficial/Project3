<?php
// ===================== Settings =====================
// The folder path where your photos and videos are stored.
// On Windows, use forward slashes (/) even for a Windows-style path.
// Example: 'C:/Users/YourName/Pictures'
define('MEDIA_ROOT', getenv('GALLERY_MEDIA_ROOT') ?: 'D:/Media');

// Allowed file extensions
define('IMAGE_EXTS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('VIDEO_EXTS', ['mp4', 'webm', 'ogg', 'mov']);

// Max width/height of thumbnails shown in the gallery grid
// Smaller value = faster grid loading (thumbnails are shown small anyway)
define('THUMB_MAX', 256);
define('THUMB_QUALITY', 60); // WebP/JPEG quality for thumbnails (0-100) — low is fine at this size

// No disk cache folder needed anymore — thumbnails are generated in memory
// and streamed straight to the browser, so no files pile up on disk.

error_reporting(E_ALL);
ini_set('display_errors', 0); // warnings printed into image/JSON responses would corrupt them
ini_set('log_errors', 1);
