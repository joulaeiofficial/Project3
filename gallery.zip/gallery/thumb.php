<?php
ob_start(); // swallow any stray warning/notice text so it can never corrupt the image bytes
require_once __DIR__ . '/includes/helpers.php';

ini_set('display_errors', '0');
$path = $_GET['path'] ?? '';
$abs = safe_path($path);

if ($abs === false || !is_file($abs) || !is_image($abs)) {
    http_response_code(404);
    exit('Not found');
}

$ext   = get_extension($abs);
$mtime = filemtime($abs);

// ---- Output format: WebP when the browser supports it (≈30% smaller), else JPEG ----
$useWebp = function_exists('imagewebp') && str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'image/webp');
$fmt  = $useWebp ? 'webp' : 'jpeg';
$etag = '"' . md5($abs . '|' . $mtime . '|' . filesize($abs) . '|' . THUMB_MAX . '|' . $fmt) . '"';

// ---- Browser cache -------------------------------------------------------------
// The gallery puts the file's mtime in the URL (&m=...), so a given URL never changes
// content: the browser can keep it "forever" and never ask the server again.
// Nothing is stored on the server's disk. If the file changes (rotate/crop) the mtime
// changes, the URL changes, and a fresh thumbnail is generated once.
header('Vary: Accept');
header('ETag: ' . $etag);
header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $mtime) . ' GMT');
header(isset($_GET['m'])
    ? 'Cache-Control: private, max-age=31536000, immutable'
    : 'Cache-Control: private, no-cache');

// Conditional request → answer 304 without decoding anything (near-zero cost)
$inm = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
$ims = isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? strtotime($_SERVER['HTTP_IF_MODIFIED_SINCE']) : false;
if ($inm === $etag || ($inm === '' && $ims !== false && $ims >= $mtime)) {
    http_response_code(304);
    exit;
}

ini_set('memory_limit', '768M'); // big photos need a lot of RAM to decode
$max = THUMB_MAX;

function send_thumb(string $bytes, string $mime): void {
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bytes));
    echo $bytes;
    exit;
}

function fail_thumb(string $why): void {
    while (ob_get_level()) ob_end_clean();
    error_log('thumb.php: ' . $why);
    http_response_code(500);
    exit(isset($_GET['debug']) ? 'Thumbnail error: ' . $why : 'Cannot process image');
}

try {
    if (!gd_available() && !class_exists('Imagick')) fail_thumb(GD_MISSING_MSG);

    // ---- Fast path 1: Imagick (decodes JPEGs at reduced size — much faster than GD) ----
    if (class_exists('Imagick')) {
        try {
            $im = new Imagick();
            if ($ext === 'jpg' || $ext === 'jpeg') {
                $im->setOption('jpeg:size', ($max * 2) . 'x' . ($max * 2));
            }
            $im->readImage($abs . '[0]');
            if (method_exists($im, 'autoOrient')) $im->autoOrient();
            $im->setImageBackgroundColor('white');
            $im = $im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
            $im->thumbnailImage($max, $max, true);
            $im->setImageFormat($fmt);
            $im->setImageCompressionQuality(THUMB_QUALITY);
            $im->stripImage();
            send_thumb($im->getImageBlob(), 'image/' . $fmt);
        } catch (Throwable $e) {
            // fall through to GD
        }
    }

    // ---- Fast path 2: tiny EXIF thumbnail embedded by cameras (only if big enough) ----
    $src = false;
    if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('exif_thumbnail')) {
        $ew = $eh = 0;
        $embedded = @exif_thumbnail($abs, $ew, $eh);
        if ($embedded !== false && $ew >= $max * 0.9 && $eh >= $max * 0.9) {
            $src = @imagecreatefromstring($embedded);
            if ($src !== false) $src = apply_exif_orientation($src, $abs);
        }
    }

    // ---- Slow path: decode the whole image with GD ----
    if ($src === false) {
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                $src = @imagecreatefromjpeg($abs);
                if ($src !== false) $src = apply_exif_orientation($src, $abs);
                break;
            case 'png':  $src = @imagecreatefrompng($abs);  break;
            case 'gif':  $src = @imagecreatefromgif($abs);  break;
            case 'webp': $src = @imagecreatefromwebp($abs); break;
        }
    }
    if ($src === false) fail_thumb('GD could not decode ' . basename($abs));

    $w = imagesx($src);
    $h = imagesy($src);
    $ratio = min($max / $w, $max / $h, 1);
    $nw = max(1, (int)round($w * $ratio));
    $nh = max(1, (int)round($h * $ratio));

    $dst = imagecreatetruecolor($nw, $nh);
    imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); // transparent PNG → white
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);

    ob_start();
    if ($useWebp) { $ok = @imagewebp($dst, null, THUMB_QUALITY); $mime = 'image/webp'; }
    else          { imageinterlace($dst, false); $ok = @imagejpeg($dst, null, THUMB_QUALITY); $mime = 'image/jpeg'; }
    $bytes = ob_get_clean();

    // WebP encoding failed on this PHP build? fall back to JPEG instead of sending nothing
    if (!$ok || $bytes === '' || $bytes === false) {
        ob_start(); imageinterlace($dst, false); imagejpeg($dst, null, THUMB_QUALITY); $bytes = ob_get_clean(); $mime = 'image/jpeg';
    }
    send_thumb($bytes, $mime);
} catch (Throwable $e) {
    fail_thumb($e->getMessage());
}
