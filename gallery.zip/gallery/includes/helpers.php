<?php
require_once __DIR__ . '/../config.php';

/**
 * Prevents path traversal outside of MEDIA_ROOT.
 * Takes a user-supplied relative path and returns a safe absolute path,
 * or false if the path is invalid.
 */
function safe_path(string $relative): string|false {
    $relative = str_replace('\\', '/', $relative);
    $relative = ltrim($relative, '/');

    // Reject any ".." segments in the path
    $parts = explode('/', $relative);
    foreach ($parts as $p) {
        if ($p === '..' || $p === '.') {
            return false;
        }
    }

    $root = realpath(MEDIA_ROOT);
    if ($root === false) {
        return false; // MEDIA_ROOT in config.php is not set correctly
    }

    $target = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);

    // Use realpath() if the file/folder exists, otherwise check the parent path
    $real = realpath($target);
    if ($real !== false) {
        $check = $real;
    } else {
        $parentReal = realpath(dirname($target));
        if ($parentReal === false) return false;
        $check = $parentReal;
    }

    // Must stay inside the root
    if (strpos($check . DIRECTORY_SEPARATOR, $root . DIRECTORY_SEPARATOR) !== 0 && $check !== $root) {
        return false;
    }

    return $target;
}

function get_extension(string $filename): string {
    return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
}

function is_image(string $filename): bool {
    return in_array(get_extension($filename), IMAGE_EXTS, true);
}

function is_video(string $filename): bool {
    return in_array(get_extension($filename), VIDEO_EXTS, true);
}

function is_media(string $filename): bool {
    return is_image($filename) || is_video($filename);
}

/**
 * Lists the contents of a folder (media files + subfolders).
 */
function list_dir(string $relative): array {
    $abs = safe_path($relative);
    $result = ['folders' => [], 'files' => []];
    if ($abs === false || !is_dir($abs)) {
        return $result;
    }

    $items = scandir($abs);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $itemAbs = $abs . DIRECTORY_SEPARATOR . $item;
        $itemRel = ($relative !== '' ? rtrim($relative, '/') . '/' : '') . $item;

        if (is_dir($itemAbs)) {
            $result['folders'][] = ['name' => $item, 'path' => $itemRel];
        } elseif (is_media($item)) {
            $result['files'][] = [
                'name' => $item,
                'path' => $itemRel,
                'type' => is_image($item) ? 'image' : 'video',
                'size' => filesize($itemAbs),
                'mtime' => filemtime($itemAbs),
            ];
        }
    }

    usort($result['folders'], fn($a, $b) => strcasecmp($a['name'], $b['name']));
    usort($result['files'], fn($a, $b) => $b['mtime'] <=> $a['mtime']);

    return $result;
}

function mime_for(string $ext): string {
    $map = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
        'gif' => 'image/gif', 'webp' => 'image/webp',
        'mp4' => 'video/mp4', 'webm' => 'video/webm', 'ogg' => 'video/ogg', 'mov' => 'video/quicktime',
    ];
    return $map[$ext] ?? 'application/octet-stream';
}

function human_size(int $bytes): string {
    $units = ['B', 'KB', 'MB', 'GB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, 1) . ' ' . $units[$i];
}

/**
 * Bakes the EXIF orientation of a JPEG into the pixels of a GD image.
 * GD ignores EXIF, but browsers honour it, so without this the thumbnail,
 * crop coordinates and rotation can disagree with what the user sees.
 */
function apply_exif_orientation($img, string $abs) {
    if (!function_exists('exif_read_data')) return $img;
    $exif = @exif_read_data($abs);
    $o = (int)($exif['Orientation'] ?? 1);
    $angle = [3 => 180, 6 => -90, 8 => 90][$o] ?? 0;
    if (in_array($o, [2, 4, 5, 7], true)) {
        imageflip($img, $o === 4 ? IMG_FLIP_VERTICAL : IMG_FLIP_HORIZONTAL);
        if ($o === 5) $angle = 90;
        if ($o === 7) $angle = -90;
    }
    if ($angle !== 0) {
        $rot = imagerotate($img, $angle, 0);
        if ($rot !== false) return $rot;
    }
    return $img;
}

const GD_MISSING_MSG = "The PHP GD extension is not enabled. Open C:\\xampp\\php\\php.ini, remove the ';' before 'extension=gd', then restart Apache in XAMPP.";

function gd_available(): bool {
    return function_exists('imagecreatefromjpeg');
}
