<?php
require_once __DIR__ . '/includes/helpers.php';

$path = $_GET['path'] ?? '';
$abs = safe_path($path);

if ($abs === false || !is_file($abs)) {
    http_response_code(404);
    exit('Not found');
}

$ext = get_extension($abs);
if (!is_media($abs)) {
    http_response_code(403);
    exit('Forbidden');
}

$mime = mime_for($ext);
$size = filesize($abs);

// Support the Range header for video (seeking)
header('Content-Type: ' . $mime);
header('Accept-Ranges: bytes');
// Short-lived cache: since the "m" parameter (based on mtime) changes in the URL,
// the browser cache is invalidated automatically; this cache only helps repeated
// loads of the same version.
header('Cache-Control: private, max-age=3600');

$fp = fopen($abs, 'rb');

if (isset($_SERVER['HTTP_RANGE'])) {
    $range = $_SERVER['HTTP_RANGE'];
    preg_match('/bytes=(\d*)-(\d*)/', $range, $matches);
    $start = $matches[1] !== '' ? (int)$matches[1] : 0;
    $end = $matches[2] !== '' ? min((int)$matches[2], $size - 1) : $size - 1;
    $length = $end - $start + 1;

    http_response_code(206);
    header("Content-Range: bytes $start-$end/$size");
    header("Content-Length: $length");
    fseek($fp, $start);
    $remaining = $length;
    while ($remaining > 0 && !feof($fp)) {
        $chunk = min(65536, $remaining);
        echo fread($fp, $chunk);
        $remaining -= $chunk;
        flush();
    }
} else {
    header("Content-Length: $size");
    fpassthru($fp);
}

fclose($fp);
