<?php
ob_start(); // keep stray warnings/notices out of the JSON
require_once __DIR__ . '/includes/helpers.php';
ini_set('memory_limit', '1024M'); // rotating/cropping big photos needs several full-size copies in RAM
@set_time_limit(120);

// If PHP dies with a fatal error (e.g. out of memory) still answer with valid JSON
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'message' => 'PHP error: ' . $e['message']], JSON_UNESCAPED_UNICODE);
    }
});

header('Content-Type: application/json; charset=utf-8');

function respond(bool $ok, string $message = '', array $extra = []): void {
    while (ob_get_level()) ob_end_clean();
    echo json_encode(array_merge(['ok' => $ok, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$path = $_POST['path'] ?? $_GET['path'] ?? '';
$abs = safe_path($path);

if ($abs === false || !is_file($abs)) {
    respond(false, 'Invalid file path.');
}


if ($action === 'delete') {
    if (unlink($abs)) {
        respond(true, 'File deleted.');
    } else {
        respond(false, 'Could not delete the file (it may be locked or in use).');
    }
}

if (!is_image($abs)) {
    respond(false, 'This action is only supported for images.');
}

$ext = get_extension($abs);

if (!gd_available()) respond(false, GD_MISSING_MSG);

function load_image(string $abs, string $ext) {
    switch ($ext) {
        case 'jpg':
        case 'jpeg':
            $im = @imagecreatefromjpeg($abs);
            return $im === false ? false : apply_exif_orientation($im, $abs);
        case 'png': return @imagecreatefrompng($abs);
        case 'gif': return @imagecreatefromgif($abs);
        case 'webp': return @imagecreatefromwebp($abs);
        default: return false;
    }
}

function save_image($img, string $abs, string $ext): bool {
    switch ($ext) {
        case 'jpg':
        case 'jpeg': return imagejpeg($img, $abs, 92);
        case 'png': return imagepng($img, $abs, 6);
        case 'gif': return imagegif($img, $abs);
        case 'webp': return imagewebp($img, $abs, 92);
        default: return false;
    }
}

if ($action === 'rotate') {
    $degrees = (int)($_POST['degrees'] ?? 90); // 90, -90, 180
    $img = load_image($abs, $ext);
    if ($img === false) respond(false, 'Could not read the image.');

    // Note: GD doesn't re-write the old EXIF orientation when saving JPEGs, and since
    // we're actually rotating the pixels themselves, the result displays correctly
    // without being rotated again by orientation metadata.
    // imagerotate() rotates counter-clockwise for a positive angle, so we negate for clockwise.
    $rotated = imagerotate($img, -$degrees, 0);
    if ($rotated === false) {
        imagedestroy($img);
        respond(false, 'Failed to rotate the image.');
    }
    if ($ext === 'png' || $ext === 'gif' || $ext === 'webp') {
        imagesavealpha($rotated, true);
    }

    // Write to a temp file then atomically rename, so we're sure the disk was actually updated.
    $tmpPath = $abs . '.tmp_' . uniqid();
    $ok = save_image($rotated, $tmpPath, $ext);
    imagedestroy($img);
    imagedestroy($rotated);

    if ($ok) {
        // clearstatcache before/after so PHP is aware of the real file state
        clearstatcache(true, $abs);
        if (!rename($tmpPath, $abs)) {
            @unlink($tmpPath);
            respond(false, 'Failed to replace the file.');
        }
        clearstatcache(true, $abs);
        touch($abs); // guarantees a new mtime so the cached thumbnail is invalidated
        clearstatcache(true, $abs);
        $newMtime = filemtime($abs);
        respond(true, '', ['mtime' => $newMtime]);
    } else {
        @unlink($tmpPath);
        respond(false, 'Failed to save the image.');
    }
}

if ($action === 'crop') {
    $x = (int)($_POST['x'] ?? 0);
    $y = (int)($_POST['y'] ?? 0);
    $w = (int)($_POST['w'] ?? 0);
    $h = (int)($_POST['h'] ?? 0);

    if ($w <= 0 || $h <= 0) respond(false, 'Invalid crop dimensions.');

    $img = load_image($abs, $ext);
    if ($img === false) respond(false, 'Could not read the image.');

    $cropped = imagecrop($img, ['x' => $x, 'y' => $y, 'width' => $w, 'height' => $h]);
    if ($cropped === false) {
        imagedestroy($img);
        respond(false, 'Crop operation failed.');
    }

    if ($ext === 'png' || $ext === 'gif' || $ext === 'webp') {
        imagesavealpha($cropped, true);
    }

    $tmpPath = $abs . '.tmp_' . uniqid();
    $ok = save_image($cropped, $tmpPath, $ext);
    imagedestroy($img);
    imagedestroy($cropped);

    if ($ok) {
        clearstatcache(true, $abs);
        if (!rename($tmpPath, $abs)) {
            @unlink($tmpPath);
            respond(false, 'Failed to replace the file.');
        }
        clearstatcache(true, $abs);
        touch($abs);
        clearstatcache(true, $abs);
        $newMtime = filemtime($abs);
        respond(true, 'Crop saved.', ['mtime' => $newMtime]);
    } else {
        @unlink($tmpPath);
        respond(false, 'Failed to save the image.');
    }
}

respond(false, 'Unknown action.');
